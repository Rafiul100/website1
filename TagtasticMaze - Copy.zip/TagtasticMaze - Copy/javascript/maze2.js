console.log('hello');

function azwer1() {
radar.src = "img/powerups/radar.svg";
}
setInterval("azwer1();", 1000);


function azwer2() {
radar.src = "img/powerups/flash.svg";
}
setInterval("azwer2();", 2000);


function azwer3() {
flash.src = "img/powerups/flash.svg";
}
setInterval("azwer3();", 1000);


function azwer4() {
flash.src = "img/powerups/radar.svg";
}
setInterval("azwer4();", 2000);








function azwer5() {
time.src = "img/powerups/time.svg";
}
setInterval("azwer5();", 1000);


function azwer6() {
time.src = "img/powerups/jump.svg";
}
setInterval("azwer6();", 2000);


function azwer7() {
jump.src = "img/powerups/jump.svg";
}
setInterval("azwer7();", 1000);


function azwer8() {
jump.src = "img/powerups/time.svg";
}
setInterval("azwer8();", 2000);





function azwer9() {
bomb.src = "img/powerups/bomb2.png";
}
setInterval("azwer9();", 1000);


function azwer10() {
bomb.src = "img/powerups/mystery.svg";
}
setInterval("azwer10();", 2000);


function azwer11() {
mystery.src = "img/powerups/mystery.svg";
}
setInterval("azwer11();", 1000);


function azwer12() {
mystery.src = "img/powerups/bomb2.png";
}
setInterval("azwer12();", 2000);




function azwer13() {
shield.src = "img/powerups/shield.svg";
}
setInterval("azwer13();", 1000);


function azwer14() {
shield.src = "img/powerups/ice-cube.svg";
}
setInterval("azwer14();", 2000);


function azwer15() {
ice.src = "img/powerups/ice-cube.svg";
}
setInterval("azwer15();", 1000);


function azwer16() {
ice.src = "img/powerups/shield.svg";
}
setInterval("azwer16();", 2000);
